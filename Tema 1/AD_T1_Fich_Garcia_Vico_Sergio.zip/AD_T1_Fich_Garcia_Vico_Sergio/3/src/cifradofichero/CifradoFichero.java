package cifradofichero;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CifradoFichero {

    public static void main(String[] args) {
        
        /*
       Cifrador cif = new Cifrador(
                {' ', 'T', 'c', 'e', 'o', 'r', 's', 't', 'x'},
                {'y','+','e','c','q',' ', 'p','m','w'});
      
        try {
            cif.cifrado("texto.txt", "textocif.txt");
        } catch (IOException ex) {
            System.out.printf("ERROR: %s\n", ex.getMessage());
        }
        
        */
        
    }
    
}
